﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ETickets.Web.Data;
using ETickets.Web.Models;

namespace ETickets.Web.Controllers
{
    public class ConcertTicketsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ConcertTicketsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: ConcertTickets
        public async Task<IActionResult> Index()
        {
            var applicationDbContext = _context.ConcertTickets.Include(c => c.Concert).Include(c => c.Ticket);
            return View(await applicationDbContext.ToListAsync());
        }

        // GET: ConcertTickets/Details/5
        public async Task<IActionResult> Details(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var concertTicket = await _context.ConcertTickets
                .Include(c => c.Concert)
                .Include(c => c.Ticket)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (concertTicket == null)
            {
                return NotFound();
            }

            return View(concertTicket);
        }

        // GET: ConcertTickets/Create
        public IActionResult Create()
        {
            ViewData["ConcertId"] = new SelectList(_context.Concerts, "Id", "ConcertName");
            ViewData["TicketId"] = new SelectList(_context.Tickets, "Id", "Id");
            return View();
        }

        // POST: ConcertTickets/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,ConcertId,date,Price,TicketId")] ConcertTicket concertTicket)
        {
            if (ModelState.IsValid)
            {
                concertTicket.Id = Guid.NewGuid();
                _context.Add(concertTicket);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["ConcertId"] = new SelectList(_context.Concerts, "Id", "ConcertName", concertTicket.ConcertId);
            ViewData["TicketId"] = new SelectList(_context.Tickets, "Id", "Id", concertTicket.TicketId);
            return View(concertTicket);
        }

        // GET: ConcertTickets/Edit/5
        public async Task<IActionResult> Edit(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var concertTicket = await _context.ConcertTickets.FindAsync(id);
            if (concertTicket == null)
            {
                return NotFound();
            }
            ViewData["ConcertId"] = new SelectList(_context.Concerts, "Id", "ConcertName", concertTicket.ConcertId);
            ViewData["TicketId"] = new SelectList(_context.Tickets, "Id", "Id", concertTicket.TicketId);
            return View(concertTicket);
        }

        // POST: ConcertTickets/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Guid id, [Bind("Id,ConcertId,date,Price,TicketId")] ConcertTicket concertTicket)
        {
            if (id != concertTicket.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(concertTicket);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ConcertTicketExists(concertTicket.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["ConcertId"] = new SelectList(_context.Concerts, "Id", "ConcertName", concertTicket.ConcertId);
            ViewData["TicketId"] = new SelectList(_context.Tickets, "Id", "Id", concertTicket.TicketId);
            return View(concertTicket);
        }

        // GET: ConcertTickets/Delete/5
        public async Task<IActionResult> Delete(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var concertTicket = await _context.ConcertTickets
                .Include(c => c.Concert)
                .Include(c => c.Ticket)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (concertTicket == null)
            {
                return NotFound();
            }

            return View(concertTicket);
        }

        // POST: ConcertTickets/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(Guid id)
        {
            var concertTicket = await _context.ConcertTickets.FindAsync(id);
            if (concertTicket != null)
            {
                _context.ConcertTickets.Remove(concertTicket);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ConcertTicketExists(Guid id)
        {
            return _context.ConcertTickets.Any(e => e.Id == id);
        }
    }
}
