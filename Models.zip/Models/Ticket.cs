﻿using System.ComponentModel.DataAnnotations;

namespace ETickets.Web.Models
{
    public class Ticket
    {
        [Key]
        public Guid Id { get; set; }
        public int NumberOfPeople { get; set; }
        public User? Owner { get; set; } 
        public Concert? Concerts { get; set; }
    }
}
