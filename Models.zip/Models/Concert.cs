﻿using System.ComponentModel.DataAnnotations;

namespace ETickets.Web.Models
{
    public class Concert
    {
        [Key]
        public Guid Id { get; set; }

        [Required(ErrorMessage = "Concert name is required")]
        public string? ConcertName { get; set; }

        public DateTime ConcertDate { get; set; }

        public double ConcertPrice { get; set; }

        public string? ConcertPlace { get; set; }

        public string? ImageUrl { get; set; } // New property for storing image URL

        // Navigation property for tickets related to this concert
        public virtual ICollection<Ticket>? Tickets { get; set; }
    }
}
