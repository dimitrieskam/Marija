﻿using System.ComponentModel.DataAnnotations;

namespace ETickets.Web.Models
{
    public class ConcertTicket
    {
        [Key]
        public Guid Id { get; set; }

        public Guid ConcertId { get; set; }
        public Concert? Concert { get; set; }
        public DateTime date { get; set; }
        public double Price { get; set; }
        public Guid TicketId { get; set; }

        public Ticket? Ticket { get; set; }
    }
}
